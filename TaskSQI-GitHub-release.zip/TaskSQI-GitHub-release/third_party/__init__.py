"""Vendored third-party code."""
